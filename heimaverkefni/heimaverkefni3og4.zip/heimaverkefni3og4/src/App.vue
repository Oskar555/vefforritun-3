<template>
  <div id="app">
    <p class="texti">filters</p>
  <div id="filters">
    <input type="radio" name="radAnswer" checked>Allt
    <input id="input1" type="radio" name="radAnswer" v-model='checked'>
    <label for="input1">Atlantsolía</label>
    <input type="radio" name="radAnswer">Costco Iceland
    <input type="radio" name="radAnswer">Dælan
    <input type="radio" name="radAnswer">N1
    <input type="radio" name="radAnswer">Olís
    <input type="radio" name="radAnswer">Orkan
    <input type="radio" name="radAnswer">Orkan X
    <input type="radio" name="radAnswer">ÓB
    <input type="radio" name="radAnswer">Skeljungur
  </div>
  <div><p id="stodvaFjoldi">fjöldi stöðva: {{ petrol.length }}</p></div>
   <div id="kassi" v-for='petrol in Sortedpatrols'>
     <h3>{{ petrol.name }}</h3>
     <h2>{{ petrol.company }}</h2>
    <div id="verd">
      <h4 class="bensin95">Bensín: {{ petrol.bensin95 }}</h4>
      <h4 class="Disel">Dísel: {{ petrol.diesel }}</h4>
    </div>
   </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data () {
    return {
      petrol: []
    };
  },
  mounted(){
    var self = this;

    axios.get('http://apis.is/petrol')
      .then(function(response){
        self.petrol = response.data.results;
      })
      .catch(function(error){
        console.log(errors)
      })
  },
  computed: {
    Sortedpatrols(){
      var stations = this.petrol.sort(function(a,b){
        return a.bensin95 - b.bensin95;
      });

      return stations.filter(function(petrol) {
        return petrol.company === 'Atlantsolía';
      });
    }
  }
}

</script>

<style lang="scss">

.texti{
  color: #d6d9db;
}

body{
  padding-left: 500px;
  padding-right: 500px;
}

#kassi{
  border: solid #d6d9db 1px;
  border-radius: 10px;
  margin-bottom: 1em;
}

.bensin95{
  
}

.Disel{

}

#verd{
  
}

#filters{
  text-align: center;
  padding-right:100px;
  padding-left:100px;

}
</style>